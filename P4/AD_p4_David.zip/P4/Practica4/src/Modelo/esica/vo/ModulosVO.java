package Modelo.esica.vo;

import java.util.ArrayList;


public class ModulosVO {
	
	private ArrayList<ModuloVO> lista;

	public ArrayList<ModuloVO> getLista() {
		return lista;
	}

	public void setLista(ArrayList<ModuloVO> lista) {
		this.lista = lista;
	}
	
	

}
