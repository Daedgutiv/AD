package Modelo.esica.vo;

import java.util.ArrayList;


public class CursanVO {

	private ArrayList<CursaVO> lista;

	public ArrayList<CursaVO> getLista() {
		return lista;
	}

	public void setLista(ArrayList<CursaVO> lista) {
		this.lista = lista;
	}
	
	
}
