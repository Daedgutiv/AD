package Modelo.esica.vo;

import java.util.ArrayList;

public class CiclosVO {
	
	
	ArrayList<CicloVO> ciclos;

	public ArrayList<CicloVO> getCiclos() {
		return ciclos;
	}

	public void setCiclos(ArrayList<CicloVO> ciclos) {
		this.ciclos = ciclos;
	}
	
	

}
