package Modelo.esica.vo;

import java.util.ArrayList;


public class AlumnosVO {

	private ArrayList<AlumnoVO> lista;

	public ArrayList<AlumnoVO> getLista() {
		return lista;
	}

	public void setLista(ArrayList<AlumnoVO> lista) {
		this.lista = lista;
	}

}
