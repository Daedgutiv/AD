package Modelo.esica.vo;

public class CicloVO {
	
	private int id;
	private String nombre;
	private String nivel;
	private int curso;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getNivel() {
		return nivel;
	}
	public void setNivel(String nivel) {
		this.nivel = nivel;
	}
	public int getCurso() {
		return curso;
	}
	public void setCurso(int cursos) {
		this.curso = cursos;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return this.id;
	}
	
	

}
