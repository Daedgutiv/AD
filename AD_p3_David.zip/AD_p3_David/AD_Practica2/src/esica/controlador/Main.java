package esica.controlador;

public class Main {

	public static void main(String[] args) {
		ModulosController mc = new ModulosController();
		mc.show();
	}
}
